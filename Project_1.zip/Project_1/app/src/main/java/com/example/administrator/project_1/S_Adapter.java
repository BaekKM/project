package com.example.administrator.project_1;

import android.app.Activity;
import android.content.Context;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by Administrator on 2017-10-19.
 */

public class S_Adapter extends ArrayAdapter<S_list>{
    private Context context;
    private int id;
    private ArrayList<S_list> S_listData;

    public S_Adapter(@NonNull Context context, @LayoutRes int resource, ArrayList<S_list> S_listData) {
        super(context, resource);
    }

    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        View row = convertView;
        if(row == null){
            LayoutInflater inflater = ((Activity)context).getLayoutInflater();
            row = inflater.inflate(id, parent, false);
        }
        TextView home = (TextView)row.findViewById(R.id.home);
        TextView N_num = (TextView)row.findViewById(R.id.N_num);
        TextView K1_num = (TextView)row.findViewById(R.id.K1_Num);
        TextView K2_num = (TextView)row.findViewById(R.id.K1_Num);

        home.setText( S_listData.get(position).getHome() + "생활관");
        N_num.setText( S_listData.get(position).getN_num());
        K1_num.setText( S_listData.get(position).getK1_num());
        K2_num.setText( S_listData.get(position).getK2_num());

        return row;
    }
}
