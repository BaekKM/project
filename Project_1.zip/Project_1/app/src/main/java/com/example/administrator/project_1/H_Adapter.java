package com.example.administrator.project_1;

import android.app.Activity;
import android.content.Context;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public  class H_Adapter extends ArrayAdapter<H_list> {
    private Context context;
    private int id;
    private ArrayList<H_list> H_listData;

    public H_Adapter(@NonNull Context context, @LayoutRes int resource, ArrayList<H_list> homeArray) {
        super(context, resource);
    }

    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        View row = convertView;
        if(row == null){
            LayoutInflater inflater = ((Activity)context).getLayoutInflater();
            row = inflater.inflate(id, parent, false);
        }
        TextView enlist = (TextView)row.findViewById(R.id.enlist);
        TextView Name = (TextView)row.findViewById(R.id.Name);
        TextView Kind = (TextView)row.findViewById(R.id.gun_kind);
        TextView State = (TextView)row.findViewById(R.id.State);
        TextView con = (TextView)row.findViewById(R.id.consideration);
        TextView g_position = (TextView)row.findViewById(R.id.gun_position);

        enlist.setText( H_listData.get(position).getEnlist());
        Name.setText( H_listData.get(position).getName());
        Kind.setText( H_listData.get(position).getGun());
        State.setText( H_listData.get(position).getState());
        con.setText( H_listData.get(position).getCon());
        g_position.setText( H_listData.get(position).getGun_position());
/*
        try{
            InputStream is = context.getAssets().open(artData.get(position).getImgName());
            Drawable d = Drawable.createFromStream(is,null);
            imageView.setImageDrawable(d);
        }catch(IOException e){
            Log.e("ERROR","ERROR: " + e);
        }
         */
        return row;
    }
}
