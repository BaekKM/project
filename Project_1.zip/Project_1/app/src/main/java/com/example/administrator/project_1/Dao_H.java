package com.example.administrator.project_1;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Created by Administrator on 2017-10-19.
 */

public class Dao_H {
    private Context context;
    private SQLiteDatabase database;

    public Dao_H(Context context){
        this.context = context;
        database = context.openOrCreateDatabase("LocalDATA.db",SQLiteDatabase.CREATE_IF_NECESSARY,null);
        try{
            String sql = "CREATE TABLE IF NOT EXISTS HomeList (ID integer primary key autoincrement,"
                    + "                                         NowNumber text UNIQUE not null,"
                    + "                                         K1Number text not null,"
                    + "                                         K2Number text not null,";
            database.execSQL(sql);
        }catch(Exception e){
            Log.e("test","CREATE TABLE FAILED! -" + e );
            e.printStackTrace();
        }
    }
    public void insertJsonData(String jsonData) {
        int Home;
        String NowNumber;
        String K1Number;
        String K2Number;

        FileDownloader fileDownloader = new FileDownloader(context);
        try {
            JSONArray jArr = new JSONArray(jsonData);
            for (int i = 0; i < jArr.length(); ++i) {
                JSONObject jObj = jArr.getJSONObject(i);

                Home = jObj.getInt("Home");
                NowNumber = jObj.getString("NowNumber");
                K1Number = jObj.getString("K1Number");
                K2Number = jObj.getString("K2Number");

                String sql = "INSERT INTO HomeList(Home, NowNumber, K1Number, K2Number)"
                        + "  VALUES(" + Home + ", " + NowNumber + ",'" + K1Number + "','" + K2Number + "');";
                try {
                    database.execSQL(sql);
                } catch (Exception e) {
                    Log.e("test", "DB ERROR! - " + e);
                    e.printStackTrace();
                }
            }
        } catch (JSONException e) {
            Log.e("test", "JSON ERROR! -" + e);
            e.printStackTrace();
        }
    }
    public ArrayList<S_list> getHomeList(){

        ArrayList<S_list>homeList = new ArrayList<S_list>();

        int Home;
        String NowNumber;
        String K1Number;
        String K2Number;

        String sql = "SELECT * FROM HomeList;";
        Cursor cursor = database.rawQuery(sql, null);
        while (cursor.moveToNext()){
            Home = cursor.getInt(1);
            NowNumber = cursor.getString(2);
            K1Number = cursor.getString(3);
            K2Number = cursor.getString(4);
            homeList.add(new S_list(Home, NowNumber, K1Number, K2Number));
        }
        cursor.close();
        return  homeList;
    }
}
