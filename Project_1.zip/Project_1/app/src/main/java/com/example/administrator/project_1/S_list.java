package com.example.administrator.project_1;

/**
 * Created by Administrator on 2017-10-19.
 */

public class S_list {
    private int home;
    private String N_num;
    private String K1_num;
    private String K2_num;
    S_list(int home, String N_num, String K1_num, String K2_num){
        this.home = home;
        this.N_num = N_num;
        this.K1_num = K1_num;
        this.K2_num = K2_num;
    }

    public int getHome() {
        return home;
    }

    public String getN_num() {
        return N_num;
    }

    public String getK1_num() {
        return K1_num;
    }

    public String getK2_num() {
        return K2_num;
    }
}
