package com.example.administrator.project_1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class Person_list extends AppCompatActivity{
    private ListView mainListView;
    private ArrayList<H_list> HomeArray;
    private TextView Title;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_person_list);

        mainListView = (ListView)findViewById(R.id.p_list);
        Title = (TextView)findViewById(R.id.title);
        listView();
    }
    public void listView(){
        Dao dao = new Dao(getApplicationContext());

        String H_Num = getIntent().getExtras().getString("HomeNumber");
        HomeArray = dao.getPersonList(Integer.parseInt(H_Num));

        Title.setText( Integer.parseInt(H_Num) + "생활관");
        H_Adapter Home_Adapter = new H_Adapter(this, R.layout.p_list,HomeArray);
        mainListView.setAdapter(Home_Adapter);

    }
}
