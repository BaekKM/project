package com.example.administrator.project_1;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;


public class Dao {
    private Context context;
    private SQLiteDatabase database;

    public Dao(Context context){
        this.context = context;
        database = context.openOrCreateDatabase("LocalDATA.db",SQLiteDatabase.CREATE_IF_NECESSARY,null);
        try{
            String sql = "CREATE TABLE IF NOT EXISTS PersonList (ID integer primary key autoincrement,"
                    + "                                         HomeNumber integer UNIQUE not null,"
                    + "                                         Name text not null,"
                    + "                                         Enlist text not null,"
                    + "                                         GunKind text not null,"
                    + "                                         GunPosition text not null,"
                    + "                                         State text not null,"
                    + "                                         Consideration text not null);";
            database.execSQL(sql);
        }catch(Exception e){
            Log.e("test","CREATE TABLE FAILED! -" + e );
            e.printStackTrace();
        }
    }
    public void insertJsonData(String jsonData) {
        int P_Num;
        int HomeNumber;
        String Name;
        String Enlist;
        String GunKind;
        String GunPosition;
        String State;
        String Consideration;

        try {
            JSONArray jArr = new JSONArray(jsonData);
            for (int i = 0; i < jArr.length(); ++i) {
                JSONObject jObj = jArr.getJSONObject(i);

                P_Num = jObj.getInt("P_Num");
                HomeNumber = jObj.getInt("HomeNumber");
                Name = jObj.getString("Name");
                Enlist = jObj.getString("Enlist");
                GunKind = jObj.getString("GunKind");
                GunPosition = jObj.getString("GunPosition");
                State = jObj.getString("State");
                Consideration = jObj.getString("Consideration");

                Log.i("test", "P_Num: " + P_Num + " Name:" + Name);

                String sql = "INSERT INTO PersonList(P_Num, HomeNumber, Name, Enlist, GunKind, GunPosition, State, Consideration)"
                        + "  VALUES(" + P_Num + ", " + HomeNumber + ",'" + Name + "','" + Enlist + "','" + GunKind + "','" + GunPosition + "','"
                        + State + "','" + Consideration + "');";
                try {
                    database.execSQL(sql);
                } catch (Exception e) {
                    Log.e("test", "DB ERROR! - " + e);
                    e.printStackTrace();
                }
            }
        } catch (JSONException e) {
            Log.e("test", "JSON ERROR! -" + e);
            e.printStackTrace();
        }
    }
    public ArrayList<H_list> getPersonList(int H_Num){

        ArrayList<H_list>personList = new ArrayList<H_list>();

        int P_Num;
        int HomeNumber;
        String Name;
        String Enlist;
        String GunKind;
        String GunPosition;
        String State;
        String Consideration;

        String sql = "SELECT * FROM PersonList;";
        Cursor cursor = database.rawQuery(sql, null);
        while (cursor.moveToNext()){
            P_Num = cursor.getInt(1);
            HomeNumber = cursor.getInt(2);
            Name = cursor.getString(3);
            Enlist = cursor.getString(4);
            GunKind = cursor.getString(5);
            GunPosition = cursor.getString(6);
            State = cursor.getString(7);
            Consideration = cursor.getString(8);
            if (HomeNumber == H_Num)
                personList.add(new H_list(P_Num, HomeNumber, Name, Enlist, GunKind, GunPosition, State, Consideration));
        }
        cursor.close();
        return  personList;
    }

}

