package com.example.administrator.project_1;

import android.util.Log;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Created by Administrator on 2017-10-20.
 */

public class Proxy_H {
    public String getJSON(){

        try{
            URL url = new URL("http://127.0.0.1:5027/loadData_H/?ArticleNumber=0");
            HttpURLConnection conn = (HttpURLConnection)url.openConnection();
            conn.setConnectTimeout(10 *1000);
            conn.setConnectTimeout(10 *1000);

            conn.setRequestMethod("GET");
            conn.setRequestProperty("Connection", "Keep-Alive");
            conn.setRequestProperty("Accept-Charset", "UTF-8");
            conn.setRequestProperty("Cache-Control", "no-cache");
            conn.setRequestProperty("Accept-Charset", "application/json_H");
            conn.setDoInput(true);

            conn.connect();
            int status = conn.getResponseCode();
            Log.i("test", "ProxyResponseCode:" + status);

            switch(status){
                case 200:
                case 201:
                    BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while((line = br.readLine()) != null){
                        sb.append(line + "\n");
                    }
                    br.close();
                    return sb.toString();
            }
        }catch(Exception e){
            e.printStackTrace();
            Log.i("test","NETWORK ERROR:" + e);
        }
        return null;
    }
}
