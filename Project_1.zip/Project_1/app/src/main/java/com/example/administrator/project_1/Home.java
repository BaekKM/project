package com.example.administrator.project_1;

import android.content.Intent;
import android.preference.PreferenceActivity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;

import java.util.ArrayList;

import cz.msebera.android.httpclient.Header;

public class Home extends AppCompatActivity implements AdapterView.OnItemClickListener{
    private ArrayList<S_list> HomeArray;
    private ListView mainListView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        mainListView = (ListView)findViewById(R.id.home_list);
        refreshData();
    }
    public void listView(){
        Dao_H dao = new Dao_H(getApplicationContext());
        HomeArray = dao.getHomeList();

        S_Adapter Home_Adapter = new S_Adapter(this, R.layout.h_list, HomeArray);
        mainListView.setAdapter(Home_Adapter);
        mainListView.setOnItemClickListener(this);
    }

    private static AsyncHttpClient client = new AsyncHttpClient();

    private void refreshData() {

    client.get("http://127.0.0.1:5027/loadData_H/?Home=0", new AsyncHttpResponseHandler() {
        @Override
        public void onSuccess(int i, Header[] headers, byte[] bytes) {
            String jsonData = new String(bytes);
            Log.i("test","jsonData: " + jsonData);

            Dao_H dao = new Dao_H(getApplicationContext());
            dao.insertJsonData(jsonData);

            listView();
        }
        @Override
        public void onFailure(int i, Header[] headers, byte[] bytes, Throwable throwable) {

        }
    });
    }
    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Intent p_list = new Intent(this, Person_list.class);
        startActivity(p_list);
    }
}
