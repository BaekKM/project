package com.example.administrator.project_1;

/**
 * Created by Administrator on 2017-10-19.
 */

public class H_list {
    private int P_Num;
    private int H_Num;//생활관 숫자
    private String Name;//이름
    private String enlist;//계급
    private String gun;//총기 종류
    private String state;//출타나 근무등 없는 경우 표시
    private String gun_position;//총기 위치
    private String con;//특이사항

    public H_list(int P_Num, int H_Num, String Name, String enlist, String gun, String state, String gun_position, String con){
        this.P_Num = P_Num;
        this.H_Num = H_Num;
        this.Name = Name;
        this.enlist = enlist;
        this.gun = gun;
        this.state = state;//위치 상태
        this.gun_position= gun_position;
        this.con = con;
    }

    public int getH_Num() {
        return H_Num;
    }

    public String getGun_position() {
        return gun_position;
    }

    public int getP_Num() {
        return P_Num;
    }

    public String getName() {
        return Name;
    }

    public String getEnlist() {
        return enlist;
    }

    public String getGun() {
        return gun;
    }

    public String getState() {
        return state;
    }

    public String getCon() {
        return con;
    }
}
